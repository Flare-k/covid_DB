<template>
  <v-content>
<!--    nuxt 요소 내부에서 pages에 작성한 .vue 컴포넌트들이 나타남-->
    <nuxt />
  </v-content>
</template>

<script>
  export default {
    name: 'LoginLayout'
  }
</script>
