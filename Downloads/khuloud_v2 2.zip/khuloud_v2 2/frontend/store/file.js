import Cookie from 'js-cookie';
import {host} from '../env'

export const state = () => ({
  importantFiles: [],
  recentFiles: [],
  files: [],
  file: null,
  currentFolder: {
    'id': 0,
    'path': '/',
    'name': 'root'
  },
  fileUrl: null,
});

export const mutations = {
  loadFolder(state, payload) {
    const {folder} = payload;
    state.currentFolder = folder;
  },
  loadFiles(state, payload) {
    const {files} = payload;
    state.files = files;
  },
  uploadFolder(state, payload) {
    const {file} = payload;
    console.log(file);
    state.files.push(file);
  },
  uploadFiles(state, payload) {
    const {files} = payload;
    console.log('mutation uploadFiles', files);
    state.files = state.files.concat(files);
  },
  deleteFile(state, payload) {
    const {fileId} = payload;
    state.file = null;
    state.files.splice(state.files.findIndex(file => file.id === fileId), 1);
  },
  downloadFile(state, payload) {
    const {fileUrl} = payload;
    state.fileUrl = fileUrl;
  }

};

export const actions = {
  loadFiles({commit}, payload) {
    return new Promise(async (resolve, reject) => {
      try {
        const {cid} = payload;
        const res = await this.$axios.get(`http://${host}/cloud/files/loadFiles?cid=${cid}`, {
          withCredentials: true
        });
        if (cid !== '0') {
          const resFolder = await this.$axios.get(`http://${host}/cloud/files/loadFolder?id=${cid}`, {
            withCredentials: true
          });
          const {folder} = resFolder.data;
          commit('loadFolder', {folder});
        }
        ;
        const {files} = res.data;
        commit('loadFiles', {files});
        return resolve();
      } catch (e) {
        console.error(e);
        return reject(e);
      }
    })
  },
  uploadFiles({commit}, payload) {
    return new Promise(async (resolve, reject) => {
      try {
        const {formData} = payload;
        const res = await this.$axios.post(`http://${host}/cloud/files/uploadFiles`, formData, {
          headers: {
            'Content-Type': 'multipart/form-data'
          }
        });
        console.log(res.data);
        const {files} = res.data;
        commit('uploadFiles', {files});
        return resolve();

      } catch (e) {
        console.error(e);
        return reject(e);
      }
    });
  },
  uploadFolder({state, commit}, payload) {
    return new Promise(async (resolve, reject) => {
      try {
        const {formData} = payload;
        console.log(formData);
        const res = await this.$axios.post(`http://${host}/cloud/files/uploadFolder`, formData, {
          headers: {
            'Content-Type': 'multipart/form-data'
          }
        });
        console.log(res.data);
        const {file} = res.data;
        commit('uploadFolder', {file});
        return resolve();

      } catch (e) {
        console.error(e);
        return reject(e);
      }
    })
  },
  deleteFile({commit}, payload) {
    return new Promise(async (resolve, reject) => {
      try {
        const {id, path} = payload;
        console.log('dispatch deleteFile', id, path);
        for (var i = 0; i < id.length; i++) {
          const res = await this.$axios.delete(`http://${host}/cloud/files/deleteTrash/${id[i]}`, {
            withCredentials: true
          });
          console.log(res.data);
          commit('deleteFile', {fileId: id[i]});
        }

      } catch (e) {
        console.error(e);
        return reject(e);
      }
    })
  },
  downloadFile({commit}, payload) {
    return new Promise(async (resolve, reject) => {
      try {
        const {id, path} = payload;
        console.log('dispatch downloadFile', id, path);
        for (var i = 0; i < id.length; i++) {
          const res = await this.$axios.get(`http://${host}/cloud/files/downloadFile/${id[i]}`, {
            withCredentials: true
          });
          console.log(res.data);
          const {file_url} = res.data;
          commit('downloadFile', {fileUrl: file_url})
        }
        return resolve();
      } catch (e) {
        console.error(e);
        return reject(e);
      }
    })
  }
  // updateFolder({commit}, payload) {
  //
  // },
  // updateFile({commit}, payload) {
  //
  // }
};
