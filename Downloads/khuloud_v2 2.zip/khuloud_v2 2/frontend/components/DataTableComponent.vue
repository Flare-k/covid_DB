<!--<template>-->
<!--  <v-layout justify-center="center" class="my-10">-->
<!--    <v-flex-->
<!--      xs12 md10>-->
<!--      <v-card elevation="0">-->
<!--        <v-card-title class="font-weight-bold">-->
<!--          내 드라이브-->
<!--          <v-spacer/>-->
<!--          <v-text-field-->
<!--            v-model="search"-->
<!--            append-icon="mdi-magnify"-->
<!--            label="검색"-->
<!--            single-line-->
<!--            hide-details-->
<!--          ></v-text-field>-->
<!--          <v-spacer/>-->
<!--          <v-menu offset-y min-width="200">-->
<!--            <template v-slot:activator="{ on }">-->
<!--              <v-btn-->
<!--                dark-->
<!--                v-on="on"-->
<!--              >-->
<!--                dropdown-->
<!--              </v-btn>-->
<!--            </template>-->
<!--            <v-list>-->
<!--              <v-list-item-content>-->
<!--                <v-list-item-title @click="deleteItem">삭제</v-list-item-title>-->
<!--              </v-list-item-content>-->
<!--              &lt;!&ndash;          <v-list-item&ndash;&gt;-->
<!--              &lt;!&ndash;            v-for="(item, i) in menu"&ndash;&gt;-->
<!--              &lt;!&ndash;            :key="i"&ndash;&gt;-->
<!--              &lt;!&ndash;          >&ndash;&gt;-->
<!--              &lt;!&ndash;            <v-list-item-title>{{ item.title }}</v-list-item-title>&ndash;&gt;-->
<!--              &lt;!&ndash;          </v-list-item>&ndash;&gt;-->
<!--            </v-list>-->
<!--          </v-menu>-->
<!--        </v-card-title>-->
<!--        <v-data-table-->
<!--          v-model="selected"-->
<!--          :headers="headers"-->
<!--          :items="files"-->
<!--          :search="search"-->
<!--          class="elevation-0"-->
<!--          show-select-->
<!--          @click:row="loadFiles"-->
<!--        >-->
<!--          <template slot="items" slot-scope="props">-->
<!--            <td>{{ props.item.name }}</td>-->
<!--            <td class="text-xs-right">{{ props.item.modifiedDate }}</td>-->
<!--            <td class="text-xs-right">{{ props.item.fileSize }}</td>-->
<!--            <td class="text-xs-right">{{ props.item.share }}</td>-->
<!--          </template>-->
<!--        </v-data-table>-->
<!--      </v-card>-->
<!--    </v-flex>-->
<!--  </v-layout>-->
<!--</template>-->

<!--<script>-->
<!--  import 'material-design-icons-iconfont/dist/material-design-icons.css'-->

<!--  export default {-->
<!--    computed: {-->
<!--      files() {-->
<!--        return this.$store.state.file.files-->
<!--      },-->
<!--      currentFolder() {-->
<!--        return this.$store.state.file.currentFolder-->
<!--      },-->
<!--    },-->
<!--    data() {-->
<!--      return {-->
<!--        selected: [],-->
<!--        search: '',-->
<!--        headers: [-->
<!--          {-->
<!--            text: '이름',-->
<!--            align: 'left',-->
<!--            sortable: 'false',-->
<!--            value: 'name',-->
<!--            width: "250px"-->
<!--          },-->
<!--          {text: '수정한 날짜', value: 'modifiedDate', width: "100px"},-->
<!--          {text: '파일 크기', value: 'filesize', width: "100px"},-->
<!--          {text: '공유', value: 'share', width: "100px"},-->
<!--          // { text: '동작', value: 'actions', sortable: false, width: "100px"},-->
<!--        ],-->
<!--        // items: [-->
<!--        //   {-->
<!--        //     name: 'Frozen Yogurt',-->
<!--        //     modifiedDate: 159,-->
<!--        //     filesize: 6.0,-->
<!--        //     share: 24,-->
<!--        //   },-->
<!--        // ],-->
<!--        menu: [-->
<!--          {title: '다운로드'},-->
<!--          {title: '삭제'},-->
<!--          {title: '이동'},-->
<!--          {title: '복사'},-->
<!--          {title: '이름 바꾸기'},-->
<!--        ],-->
<!--      }-->
<!--    },-->
<!--    methods: {-->
<!--      loadFiles(value) {-->
<!--        if (value.isFolder === true) {-->
<!--          console.log('file', value.id);-->
<!--          return this.$router.push(`/drive/file?cid=${value.id}`);-->
<!--        }-->
<!--      },-->
<!--      async deleteItem() {-->
<!--        try {-->
<!--          var id = [];-->
<!--          var path = [];-->
<!--          confirm('정말로 삭제하시겠습니까?');-->
<!--          console.log('ihihihihi', this.selected, this.selected.id);-->
<!--          for (var i = 0; i < this.selected.length; i++) {-->
<!--            id.push(this.selected[i].id);-->
<!--            path.push(this.selected[i].id);-->
<!--          }-->
<!--          await this.$store.dispatch('file/deleteFile', {id: id, path: path});-->
<!--          this.selected = [];-->
<!--        } catch (e) {-->
<!--          console.error(e);-->
<!--        }-->
<!--      },-->
<!--    },-->
<!--  }-->
<!--</script>-->

<template>
  <v-layout justify-center="center" class="my-10">
    <v-flex
      xs12 md10>
      <v-card elevation="0">
        <v-card-title class="font-weight-bold">
          내 드라이브
          <v-menu
            :close-on-content-click="false"
            :nudge-width="200"
            offset-x
            min-width="200">
            <template v-slot:activator="{ on }">
              <v-btn
                dark
                v-on="on"
                elevation="class-0"
                color="blue-grey"
                class="ma-2"
                small
                outlined
              >메뉴
              </v-btn>
            </template>
            <v-list>
              <v-list-item>
                <v-list-item-title @click="downloadItem">다운로드</v-list-item-title>
              </v-list-item>
              <v-list-item>
                <v-list-item-title @click="deleteItem">삭제</v-list-item-title>
              </v-list-item>
              <v-list-item>
                <v-list-item-title @click="">이동</v-list-item-title>
              </v-list-item>
              <v-list-item>
                <v-list-item-title @click="editItem">이름 바꾸기</v-list-item-title>
              </v-list-item>
            </v-list>
          </v-menu>
          <v-spacer/>

          <!--          검색-->
          <v-text-field
            v-model="search"
            append-icon="mdi-magnify"
            label="검색"
            single-line
            hide-details
          ></v-text-field>
          <!--          -->
        </v-card-title>
        <!--        데이터테이블 -->
        <v-data-table
          v-model="selected"
          :headers="headers"
          :items="files"
          :search="search"
          class="elevation-0"
          show-select
          @click:row="loadFiles"
        >
          <template slot="items" slot-scope="props">
            <td>{{ props.item.name }}</td>
            <td class="text-xs-right">{{ props.item.modifiedDate }}</td>
            <td class="text-xs-right">{{ props.item.fileSize }}</td>
            <td class="text-xs-right">{{ props.item.share }}</td>
          </template>
        </v-data-table>
        <!--        -->
      </v-card>
      <a :href="fileUrl" :download="fileUrl">{{fileUrl}}</a>
    </v-flex>
  </v-layout>
</template>

<script>
  import 'material-design-icons-iconfont/dist/material-design-icons.css'

  export default {
    computed: {
      files() {
        return this.$store.state.file.files
      },
      currentFolder() {
        return this.$store.state.file.currentFolder
      },
      fileUrl() {
        return this.$store.state.file.fileUrl
      }
    },
    data() {
      return {
        selected: [],
        search: '',
        editedIndex: -1,
        editedItem: {
          name: '',
        },
        headers: [
          {
            text: '이름',
            align: 'left',
            sortable: 'false',
            value: 'name',
            width: "250px"
          },
          {text: '수정한 날짜', value: 'modifiedDate', width: "100px"},
          {text: '파일 크기', value: 'filesize', width: "100px"},
          {text: '공유', value: 'share', width: "100px"},
          // { text: '동작', value: 'actions', sortable: false, width: "100px"},
        ],
        menu: [
          {title: '다운로드'},
          {title: '삭제'},
          {title: '이동'},
          {title: '복사'},
          {title: '이름 바꾸기'},
        ],
      }
    },
    methods: {
      loadFiles(value) {
        if (value.isFolder === true) {
          console.log('file', value.id);
          return this.$router.push(`/drive/file?cid=${value.id}`);
        }
      },
      async deleteItem() {
        try {
          var id = [];
          var path = [];
          var name = [];
          for (var i = 0; i < this.selected.length; i++) {
            id.push(this.selected[i].id);
            path.push(this.selected[i].path);
            name.push(this.selected[i].name);
          }
          // confirm('정말로 삭제하시겠습니까?');
          if (confirm('정말로 삭제하시겠습니까?') === true) {
            await this.$store.dispatch('file/deleteFile', {id: id, path: path});
          }
        } catch (e) {
          console.error(e);
        }
      },
      editItem(item) {
        const index = this.selected.indexOf(item);
        confirm('Are you sure you want to update this item?') && this.desserts.splice(index, 1)
      },
      async downloadItem() {
        try {
          var id = [];
          var path = [];
          var name = [];
          for (var i = 0; i < this.selected.length; i++) {
            if (this.selected[i].isFolder === false) {
              id.push(this.selected[i].id);
              path.push(this.selected[i].path);
              name.push(this.selected[i].name);
            }
          }
          await this.$store.dispatch('file/downloadFile', {id: id, path: path});

        } catch (e) {
          console.error(e);
        }
      }
    }
    ,
  }
</script>
