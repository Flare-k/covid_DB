<template>
  <v-app>
    <v-content>
      <v-container class="fill-height" fluid>
        <v-row
          align="center"
          justify="center">
          <v-col
            cols="12"
            sm="8"
            md="4"
          >
            <v-card class="elevation-2">
              <v-toolbar color="grey" dark falt>
                <v-toolbar-title>Khuloud</v-toolbar-title>
              </v-toolbar>
              <v-form v-model="valid" @submit.prevent="login">
                <v-card-text>

                  <v-text-field
                    v-model="username"
                    :rules="[rules.username]"
                    label="아이디"
                    prepend-icon="person">
                  </v-text-field>

                  <v-text-field
                    v-model="password"
                    :rules="[rules.password]"
                    type="password"
                    label="비밀번호"
                    prepend-icon="lock">
                  </v-text-field>

                </v-card-text>
                <v-card-actions>
                  <v-spacer/>
                  <v-btn
                    color="grey"
                    type="submit"
                    to="/register"
                  >
                    회원가입
                  </v-btn>
                  <v-btn
                    color="grey"
                    type="submit">
                    로그인
                  </v-btn>
                </v-card-actions>
              </v-form>
            </v-card>
          </v-col>
        </v-row>
      </v-container>
    </v-content>
  </v-app>
</template>


<script>
  export default {
    name: "LoginComponent",
    data() {
      return {
        valid: false,
        tryLogin: true,
        username: '',
        password: '',
        rules: {
          username: v => !!v || '아이디를 입력해주세요.',
          password: v => !!v || '비밀번호를 입력해주세요.',
        },
        cid: 0
      }
    },
    computed: {
      me() {
        return this.$store.state.user.me;
      }
    },
    methods: {
      async login() {
        try {
          console.log('login Method');
          await this.$store.dispatch('user/login', {
            username: this.username,
            password: this.password
          });
          await this.$router.push(`/drive/file?cid=${this.cid}`);
        } catch (e) {
          console.error(e);
        }
      },
    }
  }
</script>
