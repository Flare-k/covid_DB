<template>
  <v-app-bar
    app
    clipped-left
  >
    <v-app-bar-nav-icon @click.stop="drawer = !drawer"></v-app-bar-nav-icon>
    <v-toolbar-title>KHULOUD</v-toolbar-title>
    <v-spacer/>

    <v-menu offset-y min-width="200">
      <template v-slot:activator="{ on }">
        <v-btn
          icon
          v-on="on"
        >
          <v-icon>person</v-icon>
        </v-btn>
      </template>
      <v-list>
        <v-list-item to="/myaccount">
          <v-list-item-title>계정</v-list-item-title>
        </v-list-item>
        <v-list-item @click="logout">
          <v-list-item-title>로그아웃</v-list-item-title>
        </v-list-item>
      </v-list>
    </v-menu>

  </v-app-bar>
</template>

<script>
  export default {
    name: 'HeaderComponent',
    props: {
      source: String
    },
    methods: {
      async logout() {
        try {
          await  this.$store.dispatch('user/logout');
          await  this.$router.replace('/');
        } catch (e) {
          console.error(e);
        }
      },
    }
  }
</script>

<style scoped>
  #app {
    font-family: Avenir, Helvetica, Arial, sans-serif;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
    color: #2c3e50;
  }
</style>
