<template>
  <v-layout justify-center="center" class="my-10">
    <v-flex xs12 md10>
      <v-toolbar-title  class="font-weight-bold">최근에 사용한 항목</v-toolbar-title>
      <v-data-table :headers="headers" :items="files" hide-actions show-select hide-default-footer>
        <template slot="items" slot-scope="props">
          <td>{{ props.item.name }}</td>
          <td class="text-xs-right">{{ props.item.accessDate }}</td>
          <td class="text-xs-right">{{ props.item.owner }}</td>
          <td class="text-xs-right">{{ props.item.fileSize }}</td>
        </template>
      </v-data-table>
    </v-flex>
  </v-layout>
</template>

<script>
  export default {
    name: 'RecentTableComponent',
    data () {
      return {
        headers: [
          {
            text: '이름',
            align: 'left',
            sortable: 'false',
            value: 'name'
          },
          { text: '마지막으로 액세스한 날짜', value: 'accessDate'},
          { text: '소유자', value: 'owner'},
          { text: '파일 크기', value: 'fileSize'}
        ],
        files: [

        ]
      }
    }
  }
</script>
