import Vue from 'vue'
import Router from 'vue-router'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _fa7cc884 = () => interopDefault(import('../pages/inspire.vue' /* webpackChunkName: "pages/inspire" */))
const _76cec866 = () => interopDefault(import('../pages/login.vue' /* webpackChunkName: "pages/login" */))
const _11c81d65 = () => interopDefault(import('../pages/myaccount.vue' /* webpackChunkName: "pages/myaccount" */))
const _4ce86422 = () => interopDefault(import('../pages/register.vue' /* webpackChunkName: "pages/register" */))
const _ad32b3a6 = () => interopDefault(import('../pages/drive/file.vue' /* webpackChunkName: "pages/drive/file" */))
const _5a766568 = () => interopDefault(import('../pages/drive/recent.vue' /* webpackChunkName: "pages/drive/recent" */))
const _53e98288 = () => interopDefault(import('../pages/drive/shared-with-me.vue' /* webpackChunkName: "pages/drive/shared-with-me" */))
const _45c6155e = () => interopDefault(import('../pages/drive/starred.vue' /* webpackChunkName: "pages/drive/starred" */))
const _1b26b0d7 = () => interopDefault(import('../pages/drive/trash.vue' /* webpackChunkName: "pages/drive/trash" */))
const _0a1e0e94 = () => interopDefault(import('../pages/index.vue' /* webpackChunkName: "pages/index" */))

// TODO: remove in Nuxt 3
const emptyFn = () => {}
const originalPush = Router.prototype.push
Router.prototype.push = function push (location, onComplete = emptyFn, onAbort) {
  return originalPush.call(this, location, onComplete, onAbort)
}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: decodeURI('/'),
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/inspire",
    component: _fa7cc884,
    name: "inspire"
  }, {
    path: "/login",
    component: _76cec866,
    name: "login"
  }, {
    path: "/myaccount",
    component: _11c81d65,
    name: "myaccount"
  }, {
    path: "/register",
    component: _4ce86422,
    name: "register"
  }, {
    path: "/drive/file",
    component: _ad32b3a6,
    name: "drive-file"
  }, {
    path: "/drive/recent",
    component: _5a766568,
    name: "drive-recent"
  }, {
    path: "/drive/shared-with-me",
    component: _53e98288,
    name: "drive-shared-with-me"
  }, {
    path: "/drive/starred",
    component: _45c6155e,
    name: "drive-starred"
  }, {
    path: "/drive/trash",
    component: _1b26b0d7,
    name: "drive-trash"
  }, {
    path: "/",
    component: _0a1e0e94,
    name: "index"
  }],

  fallback: false
}

export function createRouter () {
  return new Router(routerOptions)
}
