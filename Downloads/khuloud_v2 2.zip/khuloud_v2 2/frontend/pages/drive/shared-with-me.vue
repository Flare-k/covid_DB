<template>
  <div>
    <share-table-component/>
  </div>
</template>

<script>
  import ShareTableComponent from "../../components/ShareTableComponent";
  export default {
    name: 'shared-with-me',
    components: {
      ShareTableComponent,
    }
  }
</script>
