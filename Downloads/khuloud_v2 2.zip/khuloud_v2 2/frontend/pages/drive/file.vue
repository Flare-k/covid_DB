<template>
  <div>
    <file-navbar-component/>
    <data-table-component/>
  </div>
</template>

<script>
  import DataTableComponent from "../../components/DataTableComponent";
  import FileNavbarComponent from "../../components/FileNavbarComponent";
  export default {
    watchQuery: true,
    name: 'file',
    components: {
      FileNavbarComponent,
      DataTableComponent
    },
    async fetch({store, query}) {
      console.log('fetch 중', query.cid);
      await store.dispatch('file/loadFiles', {cid: query.cid})
    }
  }
</script>
