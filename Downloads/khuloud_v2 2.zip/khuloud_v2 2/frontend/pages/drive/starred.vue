<template>
  <div>
    <data-table-component/>
  </div>
</template>

<script>
  import DataTableComponent from "../../components/DataTableComponent";
  export default {
    name: 'starred',
    components: {
      DataTableComponent
    }
  }
</script>
