<template>
  <div>
    <recent-table-component/>
  </div>
</template>

<script>
  import RecentTableComponent from "../../components/RecentTableComponent";
  export default {
    name: 'recent',
    components: {
      RecentTableComponent,
    }
  }
</script>
