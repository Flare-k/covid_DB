<template>
  <div>
    <trash-table-component/>
  </div>
</template>

<script>
  import TrashTableComponent from "../../components/TrashTableComponent";
  export default {
    name: 'trash',
    components: {
      TrashTableComponent
    }
  }
</script>
