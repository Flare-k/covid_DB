from django.urls import path, include
from cloud import views

urlpatterns = [
     # 폴더 업로드
      #query parameter <files/fileList?cid=<int>>
     path('files/loadFolder', views.loadFolder.as_view()),
     path('files/loadFiles', views.loadFiles.as_view()),
     path('files/uploadFiles', views.uploadFiles.as_view()),
     path('files/uploadFolder', views.uploadFolder.as_view()),
     path('files/deleteTrash/<int:id>', views.deleteTrash.as_view()),
     path('files/hardDelete/<int:id>', views.hardDelete.as_view()),
     path('files/restorefile', views.restore.as_view()),
     path('files/downloadFile/<int:id>', views.downloadFile.as_view()),
     # 파일 업로드
     #path('files/uploadFiles', views.FileView.as_view()),
     # 파일 리스트 전체 출력
     #path('files/fileList', views.FileList.as_view()),
     # path('files/uploadFolder', views.FolderView.as_view()),
     # 파일 삭제
     #path('files/deleteFile', views.FileDelete.as_view()),
]