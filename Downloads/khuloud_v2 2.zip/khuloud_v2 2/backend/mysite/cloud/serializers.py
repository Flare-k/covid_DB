from rest_framework import serializers
from cloud.models import File


class FileViewSerializer(serializers.ModelSerializer):
    class Meta:
        model = File
        fields = '__all__'

class FileSerializer(serializers.ModelSerializer):
    class Meta:
        model = File
        fields = ['name', 'isFolder', 'path', 'owner',
                  'filesize', 'modifiedDate', 'share', 'cid']