from django.conf import settings
import boto3
import sys
from django.conf import settings
from django.http import JsonResponse
s3 = boto3.resource('s3', aws_access_key_id=settings.AWS_ACCESS_KEY_ID,
                    aws_secret_access_key=settings.AWS_SECRET_ACCESS_KEY)
s3client = boto3.client('s3', aws_access_key_id=settings.AWS_ACCESS_KEY_ID,
                        aws_secret_access_key=settings.AWS_SECRET_ACCESS_KEY)
bucket = s3.Bucket(settings.AWS_STORAGE_BUCKET_NAME)



def create_bucket(username):
    bucket=s3client.create_bucket(
                    ACL='public-read-write',
                    Bucket=username,
                    CreateBucketConfiguration={
                            'LocationConstraint':'ap-northeast-2'},
            )

def s3_upload_file(location, file):
    try:
        print(location, file)
        s3client.put_object(Bucket=settings.AWS_STORAGE_BUCKET_NAME, Key=location, Body=file,
                            ACL="public-read")
    except Exception as e:
        print('Error on line {}'.format(
            sys.exc_info()[-1].tb_lineno), type(e).__name__, e)
        raise Exception('Upload Failed! ', e)


def s3_download_file(location):
    try:
        print(location)
        object_url = "https://s3-{0}.amazonaws.com/{1}/{2}".format(
            'ap-northeast-2', settings.AWS_STORAGE_BUCKET_NAME, location)
        return object_url
    except Exception as e:
        print('Error on line {}'.format(
            sys.exc_info()[-1].tb_lineno), type(e).__name__, e)
        raise Exception('Download Failed! ', e)


def list_path(bucket, path):
    filelist = []
    for my_bucket_object in bucket.objects.all():
        filelist.append(my_bucket_object)
    print(filelist)

    return filelist


# cloud/s3_function.py
def s3_delete_file(location):
    try:
        location = location
        response = s3client.delete_object(
            Bucket=settings.AWS_STORAGE_BUCKET_NAME, Key=location
        )
        print(response)
        message = {'message': 'Success to delete!'}
        return message
    except:
        message = {'message': 'Delete Failed'}
        return message