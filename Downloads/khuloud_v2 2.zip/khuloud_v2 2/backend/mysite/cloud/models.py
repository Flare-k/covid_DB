from djongo import models
from django.utils import timezone
from paranoid_model.models import Paranoid

class File(Paranoid):
    name = models.CharField(null=True, default='', max_length=50)
    isFolder = models.BooleanField()
    path = models.TextField()
    owner = models.CharField(null=True, default='', max_length=30)
    filesize = models.CharField(max_length=10)
    createdDate = models.DateTimeField(default=timezone.now)
    modifiedDate = models.CharField(blank=True, null=True, max_length=10)
    share = models.BooleanField(default=False)
    cid = models.IntegerField(default=0)
    class Meta:
        ordering = ['createdDate']